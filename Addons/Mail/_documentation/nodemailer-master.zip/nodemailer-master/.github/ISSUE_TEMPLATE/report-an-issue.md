---
name: Report an issue
about: Report an issue with Nodemailer
title: ''
labels: ''
assignees: ''

---

Please file only reproducible bugs. Everything else will get ignored.

See the FAQ for existing known issues [here](https://github.com/nodemailer/nodemailer#having-an-issue) before you submit a new one.
