NB! Nodemailer is frozen, so no new features please, only bug fixes.
